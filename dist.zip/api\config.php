<?php
// Zircon Host MySQL Database Configuration

define('DB_HOST', 'localhost');
define('DB_USER', 'YOUR_DB_USER');       // Replace with your Zircon cPanel MySQL Username
define('DB_PASS', 'YOUR_DB_PASSWORD');   // Replace with your Zircon cPanel MySQL Password
define('DB_NAME', 'YOUR_DB_NAME');       // Replace with your Zircon cPanel Database Name

function getDBConnection() {
    try {
        $pdo = new PDO(
            "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
            DB_USER,
            DB_PASS,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]
        );
        return $pdo;
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(["error" => "Database Connection Failed: " . $e->getMessage()]);
        exit();
    }
}
?>
